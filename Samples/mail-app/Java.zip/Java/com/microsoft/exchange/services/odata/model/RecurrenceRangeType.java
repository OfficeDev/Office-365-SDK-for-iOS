package com.microsoft.exchange.services.odata.model;

public enum RecurrenceRangeType	
{
	EndDate,
	NoEnd,
	Numbered,
}