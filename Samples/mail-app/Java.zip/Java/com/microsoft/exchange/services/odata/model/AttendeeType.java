package com.microsoft.exchange.services.odata.model;

public enum AttendeeType	
{
	Required,
	Optional,
	Resource,
}