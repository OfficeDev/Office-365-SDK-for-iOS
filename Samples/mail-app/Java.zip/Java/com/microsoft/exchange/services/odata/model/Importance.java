package com.microsoft.exchange.services.odata.model;

public enum Importance	
{
	Normal,
	Low,
	High,
}