package com.microsoft.exchange.services.odata.model;

public enum FreeBusyStatus	
{
	Unknown,
	Free,
	Tentative,
	Busy,
	Oof,
	WorkingElsewhere,
}