package com.microsoft.exchange.services.odata.model;

public enum WeekIndex	
{
	First,
	Second,
	Third,
	Fourth,
	Last,
}