package com.microsoft.exchange.services.odata.model;

public enum BodyType	
{
	Text,
	HTML,
}