package com.microsoft.exchange.services.odata.model;

public enum MeetingMessageType	
{
	None,
	MeetingRequest,
	MeetingCancelled,
	MeetingAccepted,
	MeetingTenativelyAccepted,
	MeetingDeclined,
}