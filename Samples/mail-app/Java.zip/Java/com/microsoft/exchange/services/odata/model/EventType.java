package com.microsoft.exchange.services.odata.model;

public enum EventType	
{
	SingleInstance,
	Occurrence,
	Exception,
	SeriesMaster,
}