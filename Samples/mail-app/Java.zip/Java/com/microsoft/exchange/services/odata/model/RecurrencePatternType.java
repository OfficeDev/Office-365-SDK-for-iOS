package com.microsoft.exchange.services.odata.model;

public enum RecurrencePatternType	
{
	Daily,
	Weekly,
	AbsoluteMonthly,
	RelativeMonthly,
	AbsoluteYearly,
	RelativeYearly,
}